# Homework_2                                                        03/20/25
CSCE1040 - Section 310
These are the Homework 2 files written by Benjamin Rezentes

Bmr0208
Benjaminrezentes@my.unt.edu

!!!After files were completed the program ran perfectly fine on a windows machine using ++ and mingw 64!!!

AND: I tried to only comment when neccessary because commenting on self explanatory code is not always the best for reader